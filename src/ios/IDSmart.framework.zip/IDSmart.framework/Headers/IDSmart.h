//
//  IDSmart.h
//  IDSmart SDK
//
//  Created by Edvardas Maslauskas <e.maslauskas@idscan.com>.
//  Copyright (c) 2017 IDScan Biometrics Ltd. All rights reserved.
//

#import "IDSDocumentScannerController.h"
#import "IDSEnterpriseService.h"
#import "IDSWebServices.h"
